import argparse
import csv
from datetime import datetime


def response_time(input_file):

    """
    Creating a dictionary with the total response_time and number of complaints per month + zipcode combination.
    """

    response_time_dict = {} # {Zipcode, month): {Response_time, num_complaints}

    with open(input_file, 'r') as f:
        data_dicts = csv.DictReader(f)

        for data_dict in data_dicts:
            # Checking f closed date is empty => don't want to add, need to skip them
            if data_dict["Closed Date"] == "":
                continue

            date_created = datetime.strptime(data_dict["Created Date"], "%m/%d/%Y %I:%M:%S %p") 
            date_closed = datetime.strptime(data_dict["Closed Date"], "%m/%d/%Y %I:%M:%S %p")
            month = date_closed.month # Month it was closed
            difference = date_closed - date_created
            response_time = difference.total_seconds() / 3600 # 3600 is num of seconds in an hour
            # check if response time is negative:
            if response_time < 0:
                continue

            key = (data_dict["Incident Zip"], month)


            if key not in response_time_dict:
                response_time_dict[key] = (response_time, 1)
            else:
                # Get the previous response_time and count
                previous_total_time, previous_count = response_time_dict[key]
                response_time_dict[key] = (response_time + previous_total_time, previous_count + 1)
    return response_time_dict
        

def combine_by_month(response_time_dict):
    by_month_dict = {}

    for (zipcode, month), (total_time, count) in response_time_dict.items():
        if month not in by_month_dict:
            by_month_dict[month] = (total_time, count)
        else:
            previous_total, previous_count = by_month_dict[month]
            by_month_dict[month] = (previous_total + total_time, previous_count + count)

    return by_month_dict


def calculate_averages(response_time_dict, by_zip):

    averages_dict = {}

    if by_zip:
        for (zipcode, month), (total_time, count) in response_time_dict.items(): # .items() gives you a key and a value for each entry
            average_time = total_time / count
            averages_dict[(zipcode, month)] = average_time
        
    else:
        by_month_dict = combine_by_month(response_time_dict)
        
        for month, (total_time, count) in by_month_dict.items():
            average_time = total_time / count
            averages_dict[month] = average_time



    return averages_dict



def save_averages(averages_dict, output_file, by_zip):
    with open(output_file, 'w') as f:
        writer = csv.writer(f)

        if by_zip:
            # adding header
            writer.writerow(["zipcode", "month", "average_time"])
            for (zipcode, month), average_time in averages_dict.items():
                writer.writerow([zipcode, month, average_time])
        else:
            writer.writerow(["month", "average_time"])
            for month, average_time in averages_dict.items():
                writer.writerow([month, average_time])


def main():

    parser = argparse.ArgumentParser()
    parser.add_argument("-i", "--input", required=True, help="path to input csv file")
    args = parser.parse_args()
    
    response_time_dict = response_time(args.input)

    averages_dict_mz = calculate_averages(response_time_dict, True)
    averages_dict_m = calculate_averages(response_time_dict, False)

    save_averages(averages_dict_mz, "monthly_averages_by_zip.csv", True)
    save_averages(averages_dict_m, "monthly_averages.csv", False)






if __name__ == "__main__":
    main()
