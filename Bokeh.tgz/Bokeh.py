from bokeh.plotting import figure
from bokeh.io import curdoc
from bokeh.models import Dropdown
from bokeh.layouts import column
import csv




# First line - monthly average response time for all eligible 2024 complaints, regardless of ZIP code

# create dictionary out of csv
 
overall_data = {}

with open("monthly_averages.csv", "r") as f:
    
    overall_dict  = csv.DictReader(f)

    for row in overall_dict:
        month = int(row["month"])
        average_time = float(row["average_time"])
        overall_data[month] = average_time

    # Now need to extract x-values and y-values into list
    months = sorted(overall_data.keys())
    average_times = []
    for month in months:
        average_times.append(overall_data[month])

           
# Boekh can automatically determine the ranges
p = figure(title='Response times to complaints filed through  311 service by zipcode', x_axis_label="Month", y_axis_label="Average response time (hours)")


# Creating first line - overall
p.line(months, average_times, legend_label="Overall", color="yellow")

z1 = p.line([], [], legend_label="ZIP code 1", color="orange") # empty lists because we haven't selected zipcode yet
ds1 = z1.data_source

z2 = p.line([], [], legend_label="ZIP code 2", color="pink")
ds2 = z2.data_source

# Creating zipcode dictionary
zipcode_data = {}

with open("monthly_averages_by_zip.csv", "r") as f:
    by_zip_dict = csv.DictReader(f)

    for row in by_zip_dict:
        zipcode = row["zipcode"]
        month = int(row["month"])
        average_time = float(row["average_time"])
        zipcode_data[(zipcode, month)] = average_time
     
# making list of zipcodes
zipcodes = set() # set removes duplicates (vs. list keeps them)

for zipcode, month in zipcode_data.keys():
    zipcodes.add(zipcode)


def select_zip(event, ds):
    selected_zip = event.item
    selected_data = {}

    for (zipcode, month), average_time in zipcode_data.items():
        if zipcode == selected_zip:
            selected_data[month] = average_time

    # Sorting the data and saving months and averages in two diff lists:
    zip_months = sorted(selected_data.keys()) # .keys() gives you all keys w/o values

    zip_averages = []
    for month in zip_months:
        zip_averages.append(selected_data[month])


    ds.data = {'x': zip_months, 'y': zip_averages}

    ds.trigger('data', ds.data, ds.data)



# (label, value) is how items in menu are formatted
menu = []
for zipcode in sorted(zipcodes): #sorting them makes them easier to navigate
    menu.append((zipcode, zipcode))


dropdown1 = Dropdown(label='select zipcode 1', menu=menu)
dropdown2 = Dropdown(label='select zipcode 2', menu=menu)

def select_zip1(event):
    select_zip(event, ds1)

def select_zip2(event):
    select_zip(event, ds2)

dropdown1.on_event('menu_item_click', select_zip1)
dropdown2.on_event('menu_item_click', select_zip2)


# Display it on dashboard
curdoc().add_root(column(dropdown1, dropdown2, p)) #order of column matters (determines which is up or down



